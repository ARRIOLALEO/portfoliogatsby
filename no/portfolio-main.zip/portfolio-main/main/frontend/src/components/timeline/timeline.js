import React from 'react'

function Timeline(){
  return(
    <>
      <h1>this will be my timeline </h1>
    </>
  )
}

export default Timeline
